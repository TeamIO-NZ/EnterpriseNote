package tests

func testGetNote() {

}
func testGetAllNotes() {

}
func testUpdateNote() {

}
func testDeleteNote() {

}
func testInsertNote() {

}
func testGetUser() {

}
func testGetUserByName() {

}
func testGetAllUsers() {

}
func testUpdateUser() {

}
func testDeleteUser() {

}
func testInsertUser() {

}
func testGetSpecificNotes() {

}
func testLogin() {

}
func testGetAllNotesUserHasAccessTo() {

}
