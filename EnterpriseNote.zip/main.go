package main

import "go.iosoftworks.com/EnterpriseNote/cmd/note"

func main() {
	note.Start()
}
